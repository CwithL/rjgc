package com.example.zhuyemian;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private View mEtName;
    private View metPasswd;
    private View mpsd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //初始化
        initUI();
    }

    private void initUI() {
        //获取账号，密码
        mEtName = findViewById(R.id.name);
        metPasswd = findViewById(R.id.mima);

        //
        mpsd = findViewById(R.id.remeber_passed);
    }

}
